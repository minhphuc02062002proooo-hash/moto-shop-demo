<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { header('Location: login.php'); exit; }
$res = $mysqli->query('SELECT * FROM products ORDER BY created_at DESC'); $products = $res->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="col-md-9">
  <h3>Products <a class="btn btn-sm btn-brand" href="product_add.php">Add</a></h3>
  <table class="table">
    <thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Area</th><th></th></tr></thead>
    <tbody>
      <?php foreach($products as $p): ?>
        <tr>
          <td><?= $p['id'] ?></td>
          <td><?= esc($p['name']) ?></td>
          <td><?= number_format($p['price'],0,',','.') ?>₫</td>
          <td><?= esc($p['area']) ?></td>
          <td><a href="product_edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
