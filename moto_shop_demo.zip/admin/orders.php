<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { header('Location: login.php'); exit; }
if (isset($_GET['approve'])) {
  $id = intval($_GET['approve']);
  $mysqli->query("UPDATE orders SET status='approved' WHERE id = $id");
  header('Location: orders.php'); exit;
}
$res = $mysqli->query('SELECT * FROM orders ORDER BY created_at DESC'); $orders = $res->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="col-md-9">
  <h3>Orders</h3>
  <table class="table">
    <thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($orders as $o): ?>
        <tr>
          <td><?= $o['id'] ?></td>
          <td><?= esc($o['customer_name']) ?></td>
          <td><?= number_format($o['total'],0,',','.') ?>₫</td>
          <td><?= esc($o['status']) ?></td>
          <td><a href="order_view.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
              <?php if($o['status']=='pending'): ?><a href="orders.php?approve=<?= $o['id'] ?>" class="btn btn-sm btn-success">Approve</a><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
