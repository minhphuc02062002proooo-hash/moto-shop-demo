<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare('SELECT * FROM orders WHERE id = ?'); $stmt->bind_param('i',$id); $stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt = $mysqli->prepare('SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id = ?');
$stmt->bind_param('i',$id); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="col-md-9">
  <h3>Order #<?= $order['id'] ?></h3>
  <p>Customer: <?= esc($order['customer_name']) ?> - <?= esc($order['customer_phone']) ?></p>
  <p>Payment: <?= esc($order['payment_method']) ?> <?php if($order['momo_txn_id']): ?> - Momo txn: <?= esc($order['momo_txn_id']) ?><?php endif; ?></p>
  <table class="table">
    <thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
    <tbody>
      <?php foreach($items as $it): ?><tr><td><?= esc($it['name']) ?></td><td><?= $it['quantity'] ?></td><td><?= number_format($it['price'],0,',','.') ?></td></tr><?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
