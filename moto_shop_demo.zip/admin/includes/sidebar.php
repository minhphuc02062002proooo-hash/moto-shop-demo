<div class="list-group">
  <a href="/moto_shop_demo/admin/" class="list-group-item list-group-item-action">Dashboard</a>
  <a href="/moto_shop_demo/admin/products.php" class="list-group-item list-group-item-action">Products</a>
  <a href="/moto_shop_demo/admin/orders.php" class="list-group-item list-group-item-action">Orders</a>
  <a href="/moto_shop_demo/admin/users.php" class="list-group-item list-group-item-action">Users</a>
</div>
