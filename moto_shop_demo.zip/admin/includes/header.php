<?php
require_once __DIR__ . '/../../includes/functions.php';
?>
<!doctype html><html lang="vi"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - MotoShop</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>:root{--brand:#dc3545}.bg-brand{background:var(--brand);color:#fff}.btn-brand{background:var(--brand);color:#fff;border:0}</style>
</head><body>
<nav class="navbar bg-brand p-2"><div class="container"><a class="navbar-brand text-white" href="/moto_shop_demo/admin/">Admin</a><a class="text-white" href="/moto_shop_demo/public/">View site</a></div></nav>
<div class="container-fluid mt-3">
