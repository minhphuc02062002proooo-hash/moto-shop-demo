<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/db.php';
if (!is_admin()) { header('Location: login.php'); exit; }
// simple stats
$res = $mysqli->query('SELECT COUNT(*) as c FROM products'); $products = $res->fetch_assoc()['c'];
$res = $mysqli->query('SELECT COUNT(*) as c FROM users'); $users = $res->fetch_assoc()['c'];
$res = $mysqli->query("SELECT SUM(total) as s FROM orders"); $sum = $res->fetch_assoc()['s'] ?? 0;
require_once __DIR__ . '/includes/header.php';
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-3">
      <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    </div>
    <div class="col-md-9">
      <h3>Dashboard</h3>
      <div class="row">
        <div class="col-md-4"><div class="card p-3"><h5>Products</h5><p><?= $products ?></p></div></div>
        <div class="col-md-4"><div class="card p-3"><h5>Customers</h5><p><?= $users ?></p></div></div>
        <div class="col-md-4"><div class="card p-3"><h5>Revenue</h5><p><?= number_format($sum,0,',','.') ?>₫</p></div></div>
      </div>
      <canvas id="revChart" style="max-width:700px;height:300px;"></canvas>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('revChart');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Th1','Th2','Th3','Th4','Th5','Th6'],
    datasets: [{ label: 'Doanh thu (demo)', data: [120,200,150,170,80,90] }]
  }
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
