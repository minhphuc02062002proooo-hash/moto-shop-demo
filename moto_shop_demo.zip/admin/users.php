<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { header('Location: login.php'); exit; }
$res = $mysqli->query('SELECT * FROM users ORDER BY created_at DESC'); $users = $res->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="col-md-9">
  <h3>Users</h3>
  <table class="table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr></thead><tbody>
  <?php foreach($users as $u): ?><tr><td><?= $u['id'] ?></td><td><?= esc($u['name']) ?></td><td><?= esc($u['email']) ?></td><td><?= $u['role'] ?></td></tr><?php endforeach; ?>
  </tbody></table>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
