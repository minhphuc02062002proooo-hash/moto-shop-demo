<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { header('Location: login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']); $brand = trim($_POST['brand']); $area = trim($_POST['area']);
  $price = floatval($_POST['price']); $desc = trim($_POST['description']);
  $imgpath = null;
  if (!empty($_FILES['image']['name'])) {
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fn = uniqid('p_').'.'.$ext; $dest = 'public/assets/uploads/'.$fn;
    move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/../public/assets/uploads/'.$fn);
    $imgpath = 'assets/uploads/'.$fn;
  }
  $stmt = $mysqli->prepare('INSERT INTO products (name,brand,area,price,description,image) VALUES (?,?,?,?,?,?)');
  $stmt->bind_param('sssiss',$name,$brand,$area,$price,$desc,$imgpath); $stmt->execute();
  header('Location: products.php'); exit;
}
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="col-md-9">
  <h3>Add Product</h3>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3"><label>Name</label><input name="name" class="form-control" required></div>
    <div class="mb-3"><label>Brand</label><input name="brand" class="form-control"></div>
    <div class="mb-3"><label>Area</label><input name="area" class="form-control"></div>
    <div class="mb-3"><label>Price</label><input name="price" class="form-control" type="number" required></div>
    <div class="mb-3"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
    <div class="mb-3"><label>Image</label><input name="image" type="file" class="form-control"></div>
    <button class="btn btn-brand">Save</button>
  </form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
