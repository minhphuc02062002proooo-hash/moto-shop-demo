<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // XAMPP default
$db   = 'moto_shop';

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_error) {
    die('Connection error: ' . $mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');
if (session_status() === PHP_SESSION_NONE) session_start();
