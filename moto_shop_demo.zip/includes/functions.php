<?php
require_once __DIR__ . '/../config/db.php';

function esc($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function slugify($text) {
  $text = preg_replace('~[^\pL\d]+~u', '-', $text);
  $text = iconv('utf-8','us-ascii//TRANSLIT',$text);
  $text = preg_replace('~[^-\w]+~', '', $text);
  $text = trim($text, '-');
  $text = preg_replace('~-+~', '-', $text);
  $text = strtolower($text);
  if (empty($text)) return 'n-a';
  return $text;
}

function is_admin() { return isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'; }
function is_logged() { return isset($_SESSION['user']); }
function cart_count() {
  if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) return 0;
  return array_sum($_SESSION['cart']);
}
