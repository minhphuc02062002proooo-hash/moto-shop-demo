<?php
require_once __DIR__ . '/functions.php';
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Moto Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    :root{--brand:#dc3545;}
    .brand{color:var(--brand);}
    .bg-brand{background:var(--brand); color:#fff;}
    .btn-brand{background:var(--brand); color:#fff; border:0;}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-brand">
  <div class="container">
    <a class="navbar-brand text-white" href="/moto_shop_demo/public/">MotoShop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/">Trang chủ</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/contact.php">Liên hệ</a></li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/cart.php">Giỏ hàng (<?= cart_count() ?>)</a></li>
        <?php if(is_logged()): ?>
          <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/orders.php"><?= esc($_SESSION['user']['name']) ?></a></li>
          <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link text-white" href="/moto_shop_demo/public/login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container my-4">
