</div>
<footer class="py-4 bg-light mt-5">
  <div class="container text-center">
    <small>&copy; MotoShop Demo</small>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
