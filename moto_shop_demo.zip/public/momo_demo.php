<?php
require_once __DIR__ . '/../includes/functions.php';
$order_id = intval($_GET['order_id'] ?? 0);
if (!$order_id) { header('Location: index.php'); exit; }
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param('i',$order_id); $stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) { header('Location: index.php'); exit; }

require_once __DIR__ . '/../includes/header.php';
?>
<div class="row">
  <div class="col-md-6 offset-md-3">
    <h3 class="text-center">Momo Payment Demo</h3>
    <div class="card p-3">
      <p>Order ID: <strong>#<?= $order['id'] ?></strong></p>
      <p>Số tiền cần thanh toán: <strong><?= number_format($order['total'],0,',','.') ?>₫</strong></p>
      <form method="post" action="momo_process.php">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <div class="mb-3"><label>Số điện thoại Momo (demo)</label><input name="momo_phone" class="form-control" placeholder="092xxxxxxx" required></div>
        <div class="mb-3"><label>Mô tả (tuỳ chọn)</label><input name="note" class="form-control"></div>
        <button class="btn btn-brand w-100">Thanh toán bằng Momo (Demo)</button>
      </form>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
