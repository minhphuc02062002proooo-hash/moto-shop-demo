<?php
require_once __DIR__ . '/../includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$order_id = intval($_POST['order_id']);
$momo_phone = trim($_POST['momo_phone']);
$note = trim($_POST['note'] ?? '');

// simulate momo transaction id
$txn = 'MOMO_DEMO_' . time() . '_' . rand(1000,9999);

// update order: status approved and save txn id
$stmt = $mysqli->prepare("UPDATE orders SET status = 'approved', momo_txn_id = ? WHERE id = ?");
$stmt->bind_param('si', $txn, $order_id);
$stmt->execute();

// redirect to success
header('Location: order_success.php?id=' . $order_id); exit;
