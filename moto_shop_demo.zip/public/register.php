<?php
require_once __DIR__ . '/../includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']); $email = trim($_POST['email']); $pass = $_POST['password'];
    if ($name && $email && $pass) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)');
        $role='customer';
        $stmt->bind_param('ssss',$name,$email,$hash,$role);
        if ($stmt->execute()) { header('Location: login.php'); exit; }
        else $err = 'Email đã tồn tại';
    } else $err = 'Điền đủ thông tin';
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <h3>Đăng ký</h3>
    <?php if(isset($err)): ?><div class="alert alert-danger"><?= esc($err) ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3"><label>Tên</label><input name="name" class="form-control" required></div>
      <div class="mb-3"><label>Email</label><input name="email" type="email" class="form-control" required></div>
      <div class="mb-3"><label>Password</label><input name="password" type="password" class="form-control" required></div>
      <button class="btn btn-brand">Đăng ký</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
