<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) { header('Location: cart.php'); exit; }

$items = []; $total = 0;
$ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0,count($ids),'?'));
$types = str_repeat('i', count($ids));
$stmt = $mysqli->prepare("SELECT id,name,price FROM products WHERE id IN ($placeholders)");
# bind dynamically
$params = array_merge([$types], $ids)
# Workaround: build query manually without bind for simplicity in demo
;
$q = "SELECT id,name,price FROM products WHERE id IN (".implode(',', $ids).")";
$res = $mysqli->query($q);
while($r = $res->fetch_assoc()){
    $pid = $r['id']; $qty = $_SESSION['cart'][$pid]; $line = $r['price']*$qty; $total += $line;
    $items[] = ['id'=>$pid,'name'=>$r['name'],'price'=>$r['price'],'qty'=>$qty,'line'=>$line];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cust_name = trim($_POST['customer_name']);
    $cust_phone = trim($_POST['customer_phone']);
    $cust_addr = trim($_POST['customer_address']);
    $area = trim($_POST['area']);
    $payment = $_POST['payment_method'];

    // Create order (user_id null if guest)
    $user_id = $_SESSION['user']['id'] ?? null;
    $stmt = $mysqli->prepare("INSERT INTO orders (user_id,total,payment_method,area,customer_name,customer_phone,customer_address,status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $status = 'pending';
    $stmt->bind_param('idssssss', $user_id, $total, $payment, $area, $cust_name, $cust_phone, $cust_addr, $status);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $itm = $mysqli->prepare("INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?, ?, ?, ?)");
    foreach($items as $it) {
        $itm->bind_param('iiid', $order_id, $it['id'], $it['qty'], $it['price']);
        $itm->execute();
    }
    // clear cart
    $_SESSION['cart'] = [];

    if ($payment === 'momo') {
        header('Location: momo_demo.php?order_id=' . $order_id); exit;
    } else {
        header('Location: order_success.php?id=' . $order_id); exit;
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<h2>Thanh toán</h2>
<form method="post">
  <div class="row">
    <div class="col-md-6">
      <div class="mb-3"><label>Họ tên</label><input name="customer_name" class="form-control" required></div>
      <div class="mb-3"><label>Điện thoại</label><input name="customer_phone" class="form-control" required></div>
      <div class="mb-3"><label>Địa chỉ</label><textarea name="customer_address" class="form-control" required></textarea></div>
      <div class="mb-3"><label>Khu vực</label>
        <select name="area" class="form-select" required>
          <option>HCM</option><option>Hanoi</option><option>Danang</option>
        </select>
      </div>
      <div class="mb-3"><label>Phương thức thanh toán</label>
        <select name="payment_method" class="form-select">
          <option value="store">Thanh toán tại cửa hàng</option>
          <option value="momo">Momo</option>
          <option value="credit">Thẻ tín dụng</option>
        </select>
      </div>
    </div>
    <div class="col-md-6">
      <h4>Đơn hàng</h4>
      <ul class="list-group mb-3">
        <?php foreach($items as $it): ?>
          <li class="list-group-item d-flex justify-content-between"><?= esc($it['name']) ?> x <?= $it['qty'] ?> <span><?= number_format($it['line'],0,',','.') ?>₫</span></li>
        <?php endforeach; ?>
        <li class="list-group-item d-flex justify-content-between active">Tổng <strong><?= number_format($total,0,',','.') ?>₫</strong></li>
      </ul>
      <button class="btn btn-brand">Xác nhận & Thanh toán</button>
    </div>
  </div>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
