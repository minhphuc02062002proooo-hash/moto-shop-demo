<?php
require_once __DIR__ . '/../includes/functions.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param('i',$id); $stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if (!$p) { header('Location: index.php'); exit; }
require_once __DIR__ . '/../includes/header.php';
?>
<div class="row">
  <div class="col-md-6">
    <?php if($p['image']): ?><img src="/moto_shop_demo/public/<?= esc($p['image']) ?>" class="img-fluid"><?php endif; ?>
  </div>
  <div class="col-md-6">
    <h2><?= esc($p['name']) ?></h2>
    <p class="text-muted"><?= esc($p['brand']) ?> • <?= esc($p['area']) ?></p>
    <h3 class="text-danger"><?= number_format($p['price'],0,',','.') ?>₫</h3>
    <p><?= nl2br(esc($p['description'])) ?></p>
    <form method="post" action="cart.php" class="row g-2">
      <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
      <div class="col-auto">
        <input type="number" name="qty" class="form-control" value="1" min="1" style="width:100px;">
      </div>
      <div class="col-auto">
        <button name="add" class="btn btn-brand">Thêm vào giỏ</button>
      </div>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
