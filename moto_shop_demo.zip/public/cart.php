<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $pid = intval($_POST['product_id']);
        $qty = max(1,intval($_POST['qty']));
        if (isset($_SESSION['cart'][$pid])) $_SESSION['cart'][$pid] += $qty;
        else $_SESSION['cart'][$pid] = $qty;
        header('Location: cart.php'); exit;
    }
    if (isset($_POST['update'])) {
        foreach($_POST['qty'] as $pid => $q) {
            $pid = intval($pid); $q = max(0,intval($q));
            if ($q <= 0) unset($_SESSION['cart'][$pid]);
            else $_SESSION['cart'][$pid] = $q;
        }
        header('Location: cart.php'); exit;
    }
}
require_once __DIR__ . '/../includes/header.php';

$items = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0,count($ids),'?'));
    $types = str_repeat('i', count($ids));
    $stmt = $mysqli->prepare("SELECT id,name,price FROM products WHERE id IN ($placeholders)");
    $stmt->bind_param($types, *$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    $prods = $res->fetch_all(MYSQLI_ASSOC);
    foreach($prods as $p) {
        $pid = $p['id'];
        $qty = $_SESSION['cart'][$pid];
        $line = $p['price'] * $qty;
        $total += $line;
        $items[] = ['id'=>$pid,'name'=>$p['name'],'price'=>$p['price'],'qty'=>$qty,'line'=>$line];
    }
}
?>
<h2>Giỏ hàng</h2>
<form method="post">
<table class="table">
<thead><tr><th>Sản phẩm</th><th>Giá</th><th>Số lượng</th><th>Thành tiền</th></tr></thead>
<tbody>
<?php if(empty($items)): ?>
<tr><td colspan="4">Giỏ hàng trống</td></tr>
<?php else: foreach($items as $it): ?>
<tr>
  <td><?= esc($it['name']) ?></td>
  <td><?= number_format($it['price'],0,',','.') ?>₫</td>
  <td><input type="number" name="qty[<?= $it['id'] ?>]" value="<?= $it['qty'] ?>" min="0" class="form-control" style="width:100px;"></td>
  <td><?= number_format($it['line'],0,',','.') ?>₫</td>
</tr>
<?php endforeach; endif; ?>
</tbody>
<tfoot><tr><td colspan="3" class="text-end">Tổng</td><td><?= number_format($total,0,',','.') ?>₫</td></tr></tfoot>
</table>
<div class="mb-3">
  <button name="update" class="btn btn-secondary">Cập nhật</button>
  <a href="index.php" class="btn btn-outline-primary">Tiếp tục mua</a>
  <?php if(!empty($items)): ?><a href="checkout.php" class="btn btn-brand">Thanh toán</a><?php endif; ?>
</div>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
