<?php
require_once __DIR__ . '/../includes/functions.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param('i',$id); $stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="alert alert-success">
  <h4>Đặt hàng thành công!</h4>
  <p>Mã đơn: <strong>#<?= $order['id'] ?></strong></p>
  <p>Trạng thái: <strong><?= esc($order['status']) ?></strong></p>
  <?php if($order['momo_txn_id']): ?><p>Momo txn: <?= esc($order['momo_txn_id']) ?></p><?php endif; ?>
</div>
<a href="index.php" class="btn btn-primary">Về trang chủ</a>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
