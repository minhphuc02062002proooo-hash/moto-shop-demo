<?php
require_once __DIR__ . '/../includes/functions.php';
if (!is_logged()) { header('Location: login.php'); exit; }
$user_id = $_SESSION['user']['id'];
$stmt = $mysqli->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$stmt->bind_param('i',$user_id); $stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/../includes/header.php';
?>
<h3>Lịch sử đơn hàng</h3>
<table class="table">
  <thead><tr><th>ID</th><th>Tổng</th><th>Phương thức</th><th>Trạng thái</th><th>Ngày</th><th></th></tr></thead>
  <tbody>
    <?php foreach($orders as $o): ?>
      <tr>
        <td>#<?= $o['id'] ?></td>
        <td><?= number_format($o['total'],0,',','.') ?>₫</td>
        <td><?= esc($o['payment_method']) ?></td>
        <td><?= esc($o['status']) ?></td>
        <td><?= $o['created_at'] ?></td>
        <td><a href="order_view.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-primary">Xem</a></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
