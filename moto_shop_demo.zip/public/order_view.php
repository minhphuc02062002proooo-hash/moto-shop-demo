<?php
require_once __DIR__ . '/../includes/functions.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare('SELECT * FROM orders WHERE id = ?'); $stmt->bind_param('i',$id); $stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt = $mysqli->prepare('SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id = ?');
$stmt->bind_param('i',$id); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
require_once __DIR__ . '/../includes/header.php';
?>
<h3>Chi tiết đơn hàng #<?= $order['id'] ?></h3>
<p>Khách: <?= esc($order['customer_name']) ?> - <?= esc($order['customer_phone']) ?></p>
<p>Địa chỉ: <?= nl2br(esc($order['customer_address'])) ?></p>
<p>Phương thức: <?= esc($order['payment_method']) ?> <?php if($order['momo_txn_id']): ?> - Momo txn: <?= esc($order['momo_txn_id']) ?><?php endif; ?></p>
<table class="table">
  <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Giá</th></tr></thead>
  <tbody>
    <?php foreach($items as $it): ?>
      <tr><td><?= esc($it['name']) ?></td><td><?= $it['quantity'] ?></td><td><?= number_format($it['price'],0,',','.') ?>₫</td></tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
