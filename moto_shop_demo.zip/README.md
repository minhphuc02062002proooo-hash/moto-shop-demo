# Moto Shop Demo (PHP + MySQL + Bootstrap 5)

This is a demo e-commerce project (motorbike shop) built with PHP (mysqli), MySQL and Bootstrap 5.
It includes a demo Momo payment flow: when choosing payment method "Momo" during checkout, the app redirects to a **local demo Momo page** where you can simulate payment using a demo Momo account. After "payment", the order status updates to `approved` and momo transaction id is saved.

## How to run locally (XAMPP)

1. Copy the `moto_shop_demo` folder into your XAMPP `htdocs` (or extract the zip there).
2. Start Apache and MySQL in XAMPP.
3. Import `database/moto_shop.sql` into phpMyAdmin.
   - Before importing replace `REPLACE_WITH_HASH` with password hashes, or after import change password via phpMyAdmin.
   - You can create hashes with a short PHP helper: `<?php echo password_hash('admin123', PASSWORD_DEFAULT); ?>`
4. Edit `config/db.php` if your DB credentials differ.
5. Open browser:
   - Frontend: http://localhost/moto_shop_demo/public/
   - Admin: http://localhost/moto_shop_demo/admin/

## Demo Momo payment

- On checkout choose "Momo" then the app redirects to a local momo demo page (`public/momo_demo.php`) showing the amount.
- Use any phone number as "Momo demo account" and click Pay to simulate payment.
- After success the order is updated in DB with `status = approved` and `momo_txn_id` is set.

