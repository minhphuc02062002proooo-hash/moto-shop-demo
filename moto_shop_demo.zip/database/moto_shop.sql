-- moto_shop demo database
CREATE DATABASE IF NOT EXISTS moto_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moto_shop;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  phone VARCHAR(20),
  address TEXT,
  role ENUM('admin','customer') DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  brand VARCHAR(100),
  area VARCHAR(100),
  price DECIMAL(12,2),
  description TEXT,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total DECIMAL(12,2),
  payment_method VARCHAR(50),
  area VARCHAR(100),
  status ENUM('pending','approved','canceled') DEFAULT 'pending',
  customer_name VARCHAR(100),
  customer_phone VARCHAR(20),
  customer_address TEXT,
  momo_txn_id VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT,
  quantity INT,
  price DECIMAL(12,2),
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- sample data
INSERT INTO users (name, email, password, phone, address, role) VALUES
('Admin','admin@example.com','REPLACE_WITH_HASH','0123456789','Hanoi', 'admin'),
('Khách hàng','user@example.com','REPLACE_WITH_HASH2','0987654321','HCM', 'customer');

INSERT INTO products (name, brand, area, price, description, image) VALUES
('Honda Wave Alpha','Honda','HCM',15000000,'Xe số tiết kiệm nhiên liệu','images/wave.jpg'),
('Yamaha NMAX','Yamaha','HCM',65000000,'Xe ga thời thượng','images/nmax.jpg'),
('Suzuki Raider','Suzuki','Hanoi',55000000,'Xe côn tay thể thao','images/raider.jpg');
